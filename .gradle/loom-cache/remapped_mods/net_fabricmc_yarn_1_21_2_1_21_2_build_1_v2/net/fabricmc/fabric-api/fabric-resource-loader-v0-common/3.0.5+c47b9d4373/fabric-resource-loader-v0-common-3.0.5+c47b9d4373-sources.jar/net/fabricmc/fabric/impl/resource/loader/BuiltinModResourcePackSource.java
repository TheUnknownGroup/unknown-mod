/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.resource.loader;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_5352;

public record BuiltinModResourcePackSource(String modId) implements class_5352 {
	@Override
	public boolean method_45279() {
		return true;
	}

	@Override
	public class_2561 method_45282(class_2561 packName) {
		return class_2561.method_43469("pack.nameAndSource", packName, class_2561.method_43469("pack.source.builtinMod", modId)).method_27692(class_124.field_1080);
	}
}
