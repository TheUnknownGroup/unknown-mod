/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.client.model.loading;

import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import net.fabricmc.fabric.impl.client.model.loading.ModelLoadingConstants;
import net.fabricmc.fabric.impl.client.model.loading.ModelLoadingEventDispatcher;
import net.minecraft.class_10097;
import net.minecraft.class_1091;
import net.minecraft.class_1100;
import net.minecraft.class_2960;
import net.minecraft.class_9824;

@Mixin(class_10097.class)
abstract class ReferencedModelsCollectorMixin {
	@Unique
	@Nullable
	private ModelLoadingEventDispatcher fabric_eventDispatcher;

	@Shadow
	abstract class_1100 computeResolvedModel(class_2960 identifier);

	@Shadow
	abstract void addTopLevelModel(class_1091 modelIdentifier, class_1100 unbakedModel);

	@Inject(method = "<init>", at = @At("RETURN"))
	private void onReturnInit(CallbackInfo ci) {
		fabric_eventDispatcher = ModelLoadingEventDispatcher.CURRENT.get();
	}

	@Inject(method = "addBlockStates", at = @At("RETURN"))
	private void onAddStandardModels(class_9824.class_10095 blockStateModels, CallbackInfo ci) {
		if (fabric_eventDispatcher == null) {
			return;
		}

		fabric_eventDispatcher.addExtraModels(id -> {
			class_1091 modelId = ModelLoadingConstants.toResourceModelId(id);
			class_1100 unbakedModel = computeResolvedModel(id);
			addTopLevelModel(modelId, unbakedModel);
		});
	}

	@ModifyVariable(method = "getModel", at = @At(value = "STORE", ordinal = 0), ordinal = 0)
	@Nullable
	private class_1100 onLoadResourceModel(@Nullable class_1100 model, class_2960 id) {
		if (fabric_eventDispatcher == null) {
			return model;
		}

		class_1100 resolvedModel = fabric_eventDispatcher.resolveModel(id);

		if (resolvedModel != null) {
			model = resolvedModel;
		}

		return fabric_eventDispatcher.modifyModelOnLoad(model, id, null);
	}

	@ModifyVariable(method = "addTopLevelModel", at = @At("HEAD"), argsOnly = true)
	private class_1100 onAddTopLevelModel(class_1100 model, class_1091 modelId) {
		if (fabric_eventDispatcher == null) {
			return model;
		}

		if (ModelLoadingConstants.isResourceModelId(modelId)) {
			return model;
		}

		return fabric_eventDispatcher.modifyModelOnLoad(model, null, modelId);
	}
}
