/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.mixin.content.registry;

import java.util.Map;
import net.minecraft.class_1743;
import net.minecraft.class_2248;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1743.class)
public interface AxeItemAccessor {
	@Accessor("STRIPPED_BLOCKS")
	static Map<class_2248, class_2248> getStrippedBlocks() {
		throw new AssertionError("Untransformed @Accessor");
	}

	@Accessor("STRIPPED_BLOCKS")
	@Mutable
	static void setStrippedBlocks(Map<class_2248, class_2248> strippedBlocks) {
		throw new AssertionError("Untransformed @Accessor");
	}
}
