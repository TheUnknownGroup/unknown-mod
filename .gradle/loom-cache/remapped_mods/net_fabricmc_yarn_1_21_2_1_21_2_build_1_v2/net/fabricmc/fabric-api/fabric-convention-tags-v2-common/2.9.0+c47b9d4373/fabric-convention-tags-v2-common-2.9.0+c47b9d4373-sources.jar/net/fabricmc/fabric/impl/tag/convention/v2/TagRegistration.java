/*
 * Copyright (c) 2016, 2017, 2018, 2019 FabricMC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package net.fabricmc.fabric.impl.tag.convention.v2;

import net.fabricmc.fabric.api.tag.convention.v2.TagUtil;
import net.minecraft.class_1299;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_1959;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_3195;
import net.minecraft.class_3611;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_7924;

public record TagRegistration<T>(class_5321<class_2378<T>> registryKey) {
	public static final TagRegistration<class_1792> ITEM_TAG = new TagRegistration<>(class_7924.field_41197);
	public static final TagRegistration<class_2248> BLOCK_TAG = new TagRegistration<>(class_7924.field_41254);
	public static final TagRegistration<class_1959> BIOME_TAG = new TagRegistration<>(class_7924.field_41236);
	public static final TagRegistration<class_3195> STRUCTURE_TAG = new TagRegistration<>(class_7924.field_41246);
	public static final TagRegistration<class_3611> FLUID_TAG = new TagRegistration<>(class_7924.field_41270);
	public static final TagRegistration<class_1299<?>> ENTITY_TYPE_TAG = new TagRegistration<>(class_7924.field_41266);
	public static final TagRegistration<class_1887> ENCHANTMENT_TAG = new TagRegistration<>(class_7924.field_41265);

	public class_6862<T> registerFabric(String tagId) {
		return class_6862.method_40092(registryKey, class_2960.method_60655(TagUtil.FABRIC_TAG_NAMESPACE, tagId));
	}

	public class_6862<T> registerC(String tagId) {
		return class_6862.method_40092(registryKey, class_2960.method_60655(TagUtil.C_TAG_NAMESPACE, tagId));
	}
}
