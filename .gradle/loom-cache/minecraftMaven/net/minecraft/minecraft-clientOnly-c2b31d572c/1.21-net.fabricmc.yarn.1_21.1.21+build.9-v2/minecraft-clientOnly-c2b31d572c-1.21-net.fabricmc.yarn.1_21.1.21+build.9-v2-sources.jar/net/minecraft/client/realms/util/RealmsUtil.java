/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.client.realms.util;

import com.mojang.authlib.yggdrasil.ProfileResult;
import java.util.Date;
import java.util.UUID;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.PlayerSkinDrawer;
import net.minecraft.client.util.DefaultSkinHelper;
import net.minecraft.client.util.SkinTextures;
import net.minecraft.text.Text;

@Environment(value=EnvType.CLIENT)
public class RealmsUtil {
    private static final Text NOW_TEXT = Text.translatable((String)"mco.util.time.now");
    private static final int SECONDS_PER_MINUTE = 60;
    private static final int SECONDS_PER_HOUR = 3600;
    private static final int SECONDS_PER_DAY = 86400;

    public static Text convertToAgePresentation(long milliseconds) {
        if (milliseconds < 0L) {
            return NOW_TEXT;
        }
        long l = milliseconds / 1000L;
        if (l < 60L) {
            return Text.translatable((String)"mco.time.secondsAgo", (Object[])new Object[]{l});
        }
        if (l < 3600L) {
            long m = l / 60L;
            return Text.translatable((String)"mco.time.minutesAgo", (Object[])new Object[]{m});
        }
        if (l < 86400L) {
            long m = l / 3600L;
            return Text.translatable((String)"mco.time.hoursAgo", (Object[])new Object[]{m});
        }
        long m = l / 86400L;
        return Text.translatable((String)"mco.time.daysAgo", (Object[])new Object[]{m});
    }

    public static Text convertToAgePresentation(Date date) {
        return RealmsUtil.convertToAgePresentation(System.currentTimeMillis() - date.getTime());
    }

    public static void drawPlayerHead(DrawContext context, int x, int y, int size, UUID playerUuid) {
        MinecraftClient minecraftClient = MinecraftClient.getInstance();
        ProfileResult profileResult = minecraftClient.getSessionService().fetchProfile(playerUuid, false);
        SkinTextures skinTextures = profileResult != null ? minecraftClient.getSkinProvider().getSkinTextures(profileResult.profile()) : DefaultSkinHelper.getSkinTextures(playerUuid);
        PlayerSkinDrawer.draw(context, skinTextures.texture(), x, y, size);
    }
}

