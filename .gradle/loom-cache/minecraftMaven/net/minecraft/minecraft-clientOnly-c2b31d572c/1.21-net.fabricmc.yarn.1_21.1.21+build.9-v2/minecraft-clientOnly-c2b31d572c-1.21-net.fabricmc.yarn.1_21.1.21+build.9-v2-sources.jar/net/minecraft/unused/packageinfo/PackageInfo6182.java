/*
 * Decompiled with CFR 0.2.2 (FabricMC 7c48b8c4).
 */
package net.minecraft.unused.packageinfo;

import javax.annotation.ParametersAreNonnullByDefault;
import net.fabricmc.api.EnvType;
import net.fabricmc.api.Environment;
import net.minecraft.util.annotation.ClientFieldsAreNonnullByDefault;
import net.minecraft.util.annotation.ClientMethodsReturnNonnullByDefault;

@ParametersAreNonnullByDefault
@ClientMethodsReturnNonnullByDefault
@ClientFieldsAreNonnullByDefault
@Environment(value=EnvType.CLIENT)
interface PackageInfo6182 {
}

